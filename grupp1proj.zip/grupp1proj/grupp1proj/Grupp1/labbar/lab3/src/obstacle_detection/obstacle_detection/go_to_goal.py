#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Point

class go_to_goal(Node):
    def __init__(self):
        super().__init__("go_to_goal")
        self.pub = self.create_publisher(Point, "/goal_position", 10)

    def go_to_goal(self):
        while rclpy.ok():
            choice = input("\n1. Go to position, 2. Exit: ")

            if choice == "1":
                try:
                    x = float(input("X: "))
                    y = float(input("Y: "))

                    msg = Point()
                    msg.x = x
                    msg.y = y
                    msg.z = 0.0

                    self.pub.publish(msg)
                    self.get_logger().info(f"Skickade mål: x={x}, y={y}")

                except ValueError:
                    print("Skriv giltiga tal.")

            elif choice == "2":
                break
            else:
                print("Invalid choice")

def main(args=None):
    rclpy.init(args=args)
    node = go_to_goal()

    try:
        node.go_to_goal()
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()

if __name__ == "__main__":
    main()