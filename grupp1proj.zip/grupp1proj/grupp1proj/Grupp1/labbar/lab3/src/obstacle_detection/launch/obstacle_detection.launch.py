from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, TimerAction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    # Declare the launch argument with a default value
    stop_distance_arg = DeclareLaunchArgument(
        'stop_distance',
        default_value='0.25',
        description='Distance in meters at which the robot stops when obstacles are detected'
    )
    
    # Use LaunchConfiguration to reference the argument
    stop_distance = LaunchConfiguration('stop_distance')
    
    obstacle_detection_cmd = Node(
        package='obstacle_detection',
        executable='obstacle_detection.py',
        name='obstacle_detection',
        output='screen',
        parameters=[
            {'use_sim_time': False},
            {'stop_distance': stop_distance}
        ],

        
    )
    
    # Launch the lidar visualizer node 
    lidar_visualizer_cmd = Node(
        package='obstacle_detection',
        executable='lidar_visualizer.py',
        name='lidar_visualizer',
        output='screen',
        parameters=[
            {'use_sim_time': False},
            {'stop_distance': stop_distance} 
        ],
    )

    # Launch the AStar node
    astar_cmd = Node(
        package='obstacle_detection',
        executable='Astar.py',
        name='astar_node',
        output='screen',
        parameters=[
            {'use_sim_time': False}
        ],
    )
    
    # Create and return launch description
    ld = LaunchDescription()
    ld.add_action(stop_distance_arg)
    ld.add_action(lidar_visualizer_cmd)
    # Start AStar shortly after other obstacle_detection nodes so TF/setup is ready
    ld.add_action(TimerAction(period=1.0, actions=[astar_cmd]))
    # Delay robot movement so RViz has time to start before the robot begins moving.
    # Students do not need to modify this — it is part of the given infrastructure.
    ld.add_action(TimerAction(period=10.0, actions=[obstacle_detection_cmd]))

    return ld