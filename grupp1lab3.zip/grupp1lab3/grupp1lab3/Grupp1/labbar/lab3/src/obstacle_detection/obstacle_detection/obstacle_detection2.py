#! /usr/bin/env python3
from geometry_msgs.msg import TwistStamped
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from rclpy.qos import QoSProfile
from sensor_msgs.msg import LaserScan
import math
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Pose, Point
from tf_transformations import euler_from_quaternion

class ObstacleDetection(Node):
    """
    Simple obstacle detection node that stops the robot when obstacles are too close.
    Uses a circular detection zone around the robot.
    
    TODO: Implement the detect_obstacle method to avoid obstacles!
    """
    def __init__(self):
        super().__init__("obstacle_detection")
        
        self.goal_x = 0.0
        self.goal_y = 0.0

        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.angle_min = 0.0
        self.angle_increment = 0.0

        # Safety parameters - use ROS parameter
        self.declare_parameter("stop_distance", 0.4)  # Default if not specified
        self.stop_distance = self.get_parameter("stop_distance").get_parameter_value().double_value
        self.get_logger().info(f"Using stop_distance: {self.stop_distance}m")

        self.goal_sub = self.create_subscription(
            Point,
            "/goal_position",
            self.goal_callback,
            10
        )

    def goal_callback(self, msg):
        self.goal_x = msg.x
        self.goal_y = msg.y
        self.state = "GO_TO_GOAL"
        self.get_logger().info(f"Nytt mål: x={self.goal_x}, y={self.goal_y}")

        self.pose = Pose()
        self.odom_sub = self.create_subscription(Odometry, "odom", self.get_odom_callback, qos_profile=qos_profile_sensor_data)
        # Store received data
        self.scan_ranges = []
        self.has_scan_received = False
        
        # Default motion command (slow forward)
        self.tele_twist = TwistStamped()
        self.tele_twist.twist.linear.x = 0.3
        self.tele_twist.twist.angular.z = 0.0

        # Set up quality of service
        qos = QoSProfile(depth=10)

        # Publishers and subscribers
        self.cmd_vel_pub = self.create_publisher(TwistStamped, "cmd_vel", qos)
        
        # Subscribe to laser scan data
        self.scan_sub = self.create_subscription(
            LaserScan, "scan", self.scan_callback, qos_profile=qos_profile_sensor_data
        )

        # Subscribe to teleop commands
        self.cmd_vel_raw_sub = self.create_subscription(
            TwistStamped, "cmd_vel_raw", self.cmd_vel_raw_callback, 
            qos_profile=qos_profile_sensor_data
        )

        # Set up timer for regular checking
        self.timer = self.create_timer(0.1, self.timer_callback)

    def get_odom_callback(self, msg: Odometry):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

        q = msg.pose.pose.orientation
        _, _, self.theta = euler_from_quaternion([q.x, q.y, q.z, q.w])
        self.get_logger().info(f"Robot state  {self.x - 1.5, self.y - 0.5, self.theta}")

    def normalize_angle(self, angle: float) -> float:
        return math.atan2(math.sin(angle), math.cos(angle))

    def scan_callback(self, msg: LaserScan):
        # Store scan data for use in detect_obstacle
        self.scan_ranges = msg.ranges
        self.angle_min = msg.angle_min
        self.angle_increment = msg.angle_increment
        self.has_scan_received = True


    def cmd_vel_raw_callback(self, msg):
        """Store teleop commands when received"""
        self.tele_twist = msg

    def timer_callback(self):
        """Regular function to check for obstacles"""
        if self.has_scan_received:
            self.detect_obstacle()

    def detect_obstacle(self):
        """Detect obstacles and navigate toward the goal while avoiding collisions."""
        valid_ranges = [
            (i, r)
            for i, r in enumerate(self.scan_ranges)
            if not math.isinf(r) and not math.isnan(r) and r > 0.01
        ]

        nearest_distance = float('inf')
        avoid_x = 0.0
        avoid_y = 0.0
        obstacle_weight = 0.0

        for i, r in valid_ranges:
            angle = self.angle_min + i * self.angle_increment
            angle = self.normalize_angle(angle)
            if abs(angle) > math.pi / 2:
                continue

            if r < nearest_distance:
                nearest_distance = r

            if r < self.stop_distance * 1.5:
                weight = (self.stop_distance * 1.5 - r) / max(r, 0.01)
                obstacle_weight += weight
                avoid_x += weight * math.cos(angle)
                avoid_y += weight * math.sin(angle)

        if obstacle_weight > 0.0:
            avoid_heading = math.atan2(avoid_y, avoid_x) + math.pi
            avoid_heading = math.atan2(math.sin(avoid_heading), math.cos(avoid_heading))
        else:
            avoid_heading = 0.0

        dx = self.goal_x - self.x
        dy = self.goal_y - self.y
        distance = math.sqrt(dx * dx + dy * dy)
        goal_theta = math.atan2(dy, dx)

        e_goal = math.atan2(math.sin(goal_theta - self.theta), math.cos(goal_theta - self.theta))
        e_avoid = math.atan2(math.sin(avoid_heading - self.theta), math.cos(avoid_heading - self.theta))

        if nearest_distance <= self.stop_distance:
            w_goal = 0.0
        elif nearest_distance >= self.stop_distance * 1.5:
            w_goal = 1.0
        else:
            w_goal = (nearest_distance - self.stop_distance) / (0.5 * self.stop_distance)
        w_goal = max(0.0, min(1.0, w_goal))
        w_avoid = 1.0 - w_goal

        e_combined = w_goal * e_goal + w_avoid * e_avoid

        twist = TwistStamped()
        if distance > 0.1:
            twist.twist.linear.x = 0.05 + 0.15 * w_goal
            if nearest_distance <= self.stop_distance:
                twist.twist.linear.x = 0.05
            twist.twist.angular.z = 0.8 * e_combined
        else:
            twist.twist.linear.x = 0.0
            twist.twist.angular.z = 0.0

        self.cmd_vel_pub.publish(twist)

    def destroy_node(self):
        """Publish zero velocity when node is destroyed"""
        self.get_logger().info("Shutting down, stopping robot...")
        stop_twist = TwistStamped() # Default TwistStamped has all zeros
        self.cmd_vel_pub.publish(stop_twist)
        super().destroy_node() # Call the parent class's destroy_node


def main(args=None):
    rclpy.init(args=args)
    obstacle_detection = ObstacleDetection()
    try:
        rclpy.spin(obstacle_detection)
    except KeyboardInterrupt:
        obstacle_detection.get_logger().info('KeyboardInterrupt caught, allowing rclpy to shutdown.')
    finally:
        obstacle_detection.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()


'''
command snippets:
ros2 topic pub /cmd_vel geometry_msgs/msg/TwistStamped "{header: {stamp: {sec: 0, nanosec: 0}, frame_id: ''}, twist: {linear: {x: 0.0, y: 0.0, z: 0.0}, angular: {x: 0.0, y: 0.0, z: 0.0}}}" -1
# to stop the robot, publish zero velocity to cmd_vel
ros2 run obstacle_detection go_to_goal.py 
# go to goal
ros2 launch bringup main.launch.py
#run the main script
ros2 launch turtlebot3_navigation2 navigation2.launch.py map:=$HOME/map.yaml
#3.2 run the map redo path later on
ros2 launch turtlebot3_bringup robot.launch.py
# run the robot on the pi
Robot 1: ssh pi@130.243.66.71
# ssh to the robot, replace last 71 with 7x x=number on the robot
'''