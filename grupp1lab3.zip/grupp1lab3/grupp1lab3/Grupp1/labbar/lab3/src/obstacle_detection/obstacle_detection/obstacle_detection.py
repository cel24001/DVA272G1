#! /usr/bin/env python3
from geometry_msgs.msg import Twist
import rclpy
from rclpy.node import Node
from rclpy.qos import qos_profile_sensor_data
from rclpy.qos import QoSProfile
from sensor_msgs.msg import LaserScan
import math
from nav_msgs.msg import Odometry
from geometry_msgs.msg import Pose
import math
from tf_transformations import euler_from_quaternion


class ObstacleDetection(Node):
    """
    Simple obstacle detection node that stops the robot when obstacles are too close.
    Uses a circular detection zone around the robot.
    
    TODO: Implement the detect_obstacle method to avoid obstacles!
    """
    def __init__(self):
        super().__init__("obstacle_detection")
        # Safety parameters - use ROS parameter
        self.declare_parameter("stop_distance", 0.25)  # Default if not specified
        self.stop_distance = self.get_parameter("stop_distance").get_parameter_value().double_value
        self.get_logger().info(f"Using stop_distance: {self.stop_distance}m")
        self.pose = Pose()
        
        # Store received data
        self.scan_ranges = []
        self.has_scan_received = False
        
        # Default motion command (slow forward)
        self.tele_twist = Twist()
        self.tele_twist.linear.x = 0.2
        self.tele_twist.angular.z = 0.0

        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.angle_min = 0.0
        self.angle_increment = 0.0

        self.state = "GoToGoal"  # "GoToGoal", "TurnAvoid", "DriveForward"
        self.avoid_direction = 0   # +1 vänster, -1 höger
        self.avoid_target_theta = 0.0
        self.forward_start_x = 0.0
        self.forward_start_y = 0.0
        self.forward_distance = 0.3

        self.goal_x = 1.1 + (1.5)
        self.goal_y = 0.5 + (0.5)
        
        # Set up quality of service
        qos = QoSProfile(depth=10)

        # Publishers and subscribers
        self.cmd_vel_pub = self.create_publisher(Twist, "cmd_vel", qos)
        self.odom_sub = self.create_subscription(Odometry, "odom", self.odom_callback, qos_profile=qos_profile_sensor_data)
        
        
        # Subscribe to laser scan data
        self.scan_sub = self.create_subscription(
            LaserScan, "scan", self.scan_callback, qos_profile=qos_profile_sensor_data
        )

        # Subscribe to teleop commands
        self.cmd_vel_raw_sub = self.create_subscription(
            Twist, "cmd_vel_raw", self.cmd_vel_raw_callback, 
            qos_profile=qos_profile_sensor_data
        )

        # Set up timer for regular checking
        self.timer = self.create_timer(0.1, self.timer_callback)

    def odom_callback(self, msg):
        self.pose = msg.pose.pose
        self.x = self.pose.position.x
        self.y = self.pose.position.y

        q = self.pose.orientation
        _, _, self.theta = euler_from_quaternion([q.x, q.y, q.z, q.w])

    def scan_callback(self, msg):
        self.scan_ranges = msg.ranges
        self.angle_min = msg.angle_min
        self.angle_increment = msg.angle_increment
        self.has_scan_received = True

    def cmd_vel_raw_callback(self, msg):
        """Store teleop commands when received"""
        self.tele_twist = msg

    def timer_callback(self):
        """Regular function to check for obstacles"""
        if self.has_scan_received:
            self.detect_obstacle()

    def normalize_angle(self, angle):
        """Normalize angle to [-pi, pi]"""
        return math.atan2(math.sin(angle), math.cos(angle))

    def detect_obstacle(self):
        # 1. Ta bara scan framåt inom ±90 grader
        twist = Twist()
        front_ranges = []
        for i, r in enumerate(self.scan_ranges):
            if not math.isfinite(r) or r <= 0.01:
                continue

            angle = self.angle_min + i * self.angle_increment
            angle = self.normalize_angle(angle)

            if -math.pi / 2 <= angle <= math.pi / 2:
                front_ranges.append((i, r, angle))

        # Om ingen vettig scan finns
        if not front_ranges:
            self.cmd_vel_pub.publish(twist)
            return

        _, obstacle_distance, obstacle_angle = min(front_ranges, key=lambda x: x[1])

        if self.state == "GoToGoal":
            if obstacle_distance < self.stop_distance:
                # välj riktning bort från hindret
                if obstacle_angle > 0:
                    self.avoid_direction = -1   # hinder vänster -> sväng höger
                else:
                    self.avoid_direction = 1    # hinder höger -> sväng vänster

                self.avoid_target_theta = self.normalize_angle(
                    self.theta + self.avoid_direction * (math.pi / 2)
                )

                self.state = "TurnAvoid"

            else:
                dx = self.goal_x - self.x
                dy = self.goal_y - self.y
                distance_to_goal = math.sqrt(dx * dx + dy * dy)

                if distance_to_goal < 0.1:
                    twist.linear.x = 0.0
                    twist.angular.z = 0.0
                else:
                    angle_to_goal = math.atan2(dy, dx)
                    e_theta = self.normalize_angle(angle_to_goal - self.theta)

                    if abs(e_theta) > 0.2:
                        twist.linear.x = 0.0
                        twist.angular.z = 1.2 * e_theta
                    else:
                        twist.linear.x = 0.18
                        twist.angular.z = 0.6 * e_theta
        elif self.state == "TurnAvoid":
            e_theta = self.normalize_angle(self.avoid_target_theta - self.theta)

            if abs(e_theta) > 0.08:
                twist.linear.x = 0.0
                twist.angular.z = 1.0 * e_theta
            else:
                twist.linear.x = 0.0
                twist.angular.z = 0.0
                self.forward_start_x = self.x
                self.forward_start_y = self.y
                self.state = "DriveForward"
        elif self.state == "DriveForward":
            travelled = math.sqrt(
                (self.x - self.forward_start_x) ** 2 +
                (self.y - self.forward_start_y) ** 2
            )

            if travelled < self.forward_distance:
                twist.linear.x = 0.15
                twist.angular.z = 0.0
            else:
                self.state = "GoToGoal"

        self.cmd_vel_pub.publish(twist)

    def destroy_node(self):
        """Publish zero velocity when node is destroyed"""
        self.get_logger().info("Shutting down, stopping robot...")
        stop_twist = Twist() # Default Twist has all zeros
        self.cmd_vel_pub.publish(stop_twist)
        super().destroy_node() # Call the parent class's destroy_node

def main(args=None):
    rclpy.init(args=args)
    obstacle_detection = ObstacleDetection()
    try:
        rclpy.spin(obstacle_detection)
    except KeyboardInterrupt:
        obstacle_detection.get_logger().info('KeyboardInterrupt caught, allowing rclpy to shutdown.')
    finally:
        obstacle_detection.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
